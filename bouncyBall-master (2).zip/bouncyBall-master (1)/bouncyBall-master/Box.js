
//object have properties and function
class Box{
constructor(x,y,width,height){
    //this refer to object
    var option={
        restitution:0.8
    }
    this.box=Bodies.rectangle(x,y,width,height,option);
    this.width=width
    this.height=height
    World.add(world,this.box);

}
display(){
    rectMode(CENTER);
    fill("red")
    stroke("yellow")
    strokeWeight(5)
    rect(this.box.position.x,this.box.position.y,this.width,this.height);
}

}